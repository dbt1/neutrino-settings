# QA Report – unknown

- Source ID: `unknown`
- Services total: 1885
- Distribution: SAT=1565, CABLE=0, TERRESTRIAL=320, RADIO=262
- Bouquets: 41
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
