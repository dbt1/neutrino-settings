# QA Report – unknown

- Source ID: `unknown`
- Services total: 1836
- Distribution: SAT=1563, CABLE=0, TERRESTRIAL=273, RADIO=253
- Bouquets: 41
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
