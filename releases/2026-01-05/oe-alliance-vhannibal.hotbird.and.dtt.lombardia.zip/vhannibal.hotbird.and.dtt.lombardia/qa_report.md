# QA Report – unknown

- Source ID: `unknown`
- Services total: 1831
- Distribution: SAT=1510, CABLE=0, TERRESTRIAL=321, RADIO=258
- Bouquets: 41
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
