# QA Report – unknown

- Source ID: `unknown`
- Services total: 12628
- Distribution: SAT=12628, CABLE=0, TERRESTRIAL=0, RADIO=1979
- Bouquets: 47
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
