# QA Report – unknown

- Source ID: `unknown`
- Services total: 1979
- Distribution: SAT=1598, CABLE=0, TERRESTRIAL=381, RADIO=274
- Bouquets: 43
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
