# QA Report – unknown

- Source ID: `unknown`
- Services total: 1871
- Distribution: SAT=1563, CABLE=0, TERRESTRIAL=308, RADIO=261
- Bouquets: 42
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
