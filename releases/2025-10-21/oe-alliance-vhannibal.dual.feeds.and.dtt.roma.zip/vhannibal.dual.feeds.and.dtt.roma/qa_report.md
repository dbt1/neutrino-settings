# QA Report – unknown

- Source ID: `unknown`
- Services total: 3166
- Distribution: SAT=2785, CABLE=0, TERRESTRIAL=381, RADIO=424
- Bouquets: 46
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
