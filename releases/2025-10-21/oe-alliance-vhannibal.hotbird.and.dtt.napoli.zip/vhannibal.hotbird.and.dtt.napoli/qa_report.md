# QA Report – unknown

- Source ID: `unknown`
- Services total: 2031
- Distribution: SAT=1608, CABLE=0, TERRESTRIAL=423, RADIO=281
- Bouquets: 42
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
