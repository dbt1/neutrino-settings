# QA Report – unknown

- Source ID: `unknown`
- Services total: 3219
- Distribution: SAT=2796, CABLE=0, TERRESTRIAL=423, RADIO=431
- Bouquets: 45
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
