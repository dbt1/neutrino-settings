# QA Report – unknown

- Source ID: `unknown`
- Services total: 1877
- Distribution: SAT=1566, CABLE=0, TERRESTRIAL=311, RADIO=264
- Bouquets: 41
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
