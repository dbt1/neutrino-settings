# QA Report – unknown

- Source ID: `unknown`
- Services total: 2986
- Distribution: SAT=2675, CABLE=0, TERRESTRIAL=311, RADIO=409
- Bouquets: 44
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
