# QA Report – unknown

- Source ID: `unknown`
- Services total: 14779
- Distribution: SAT=14316, CABLE=0, TERRESTRIAL=463, RADIO=2298
- Bouquets: 48
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
