# QA Report – unknown

- Source ID: `unknown`
- Services total: 12689
- Distribution: SAT=12689, CABLE=0, TERRESTRIAL=0, RADIO=1984
- Bouquets: 47
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
