# QA Report – unknown

- Source ID: `unknown`
- Services total: 14467
- Distribution: SAT=14060, CABLE=0, TERRESTRIAL=407, RADIO=2231
- Bouquets: 50
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
