# QA Report – unknown

- Source ID: `unknown`
- Services total: 12933
- Distribution: SAT=12627, CABLE=0, TERRESTRIAL=306, RADIO=2003
- Bouquets: 48
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
