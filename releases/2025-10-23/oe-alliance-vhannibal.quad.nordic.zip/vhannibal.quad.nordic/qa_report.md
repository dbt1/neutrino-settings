# QA Report – unknown

- Source ID: `unknown`
- Services total: 3965
- Distribution: SAT=3965, CABLE=0, TERRESTRIAL=0, RADIO=465
- Bouquets: 44
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
