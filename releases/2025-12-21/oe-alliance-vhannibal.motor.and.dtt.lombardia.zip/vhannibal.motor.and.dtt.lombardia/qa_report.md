# QA Report – unknown

- Source ID: `unknown`
- Services total: 12874
- Distribution: SAT=12552, CABLE=0, TERRESTRIAL=322, RADIO=1996
- Bouquets: 48
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
