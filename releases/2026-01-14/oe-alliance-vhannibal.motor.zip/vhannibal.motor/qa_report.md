# QA Report – unknown

- Source ID: `unknown`
- Services total: 12346
- Distribution: SAT=12346, CABLE=0, TERRESTRIAL=0, RADIO=1953
- Bouquets: 47
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
