# QA Report – unknown

- Source ID: `unknown`
- Services total: 14475
- Distribution: SAT=14094, CABLE=0, TERRESTRIAL=381, RADIO=2220
- Bouquets: 49
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
