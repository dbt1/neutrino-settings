# QA Report – unknown

- Source ID: `unknown`
- Services total: 1875
- Distribution: SAT=1566, CABLE=0, TERRESTRIAL=309, RADIO=263
- Bouquets: 42
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
