# QA Report – unknown

- Source ID: `unknown`
- Services total: 12942
- Distribution: SAT=12633, CABLE=0, TERRESTRIAL=309, RADIO=2007
- Bouquets: 48
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
