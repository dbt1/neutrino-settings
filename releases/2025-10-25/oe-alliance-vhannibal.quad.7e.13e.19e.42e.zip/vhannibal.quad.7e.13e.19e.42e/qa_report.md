# QA Report – unknown

- Source ID: `unknown`
- Services total: 3776
- Distribution: SAT=3776, CABLE=0, TERRESTRIAL=0, RADIO=557
- Bouquets: 43
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
