# QA Report – unknown

- Source ID: `unknown`
- Services total: 2994
- Distribution: SAT=2674, CABLE=0, TERRESTRIAL=320, RADIO=407
- Bouquets: 44
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
