# QA Report – unknown

- Source ID: `unknown`
- Services total: 12960
- Distribution: SAT=12661, CABLE=0, TERRESTRIAL=299, RADIO=2009
- Bouquets: 48
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
