# QA Report – unknown

- Source ID: `unknown`
- Services total: 12740
- Distribution: SAT=12419, CABLE=0, TERRESTRIAL=321, RADIO=1980
- Bouquets: 48
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
