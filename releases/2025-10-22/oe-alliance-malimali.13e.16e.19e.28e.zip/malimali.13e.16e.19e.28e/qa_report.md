# QA Report – unknown

- Source ID: `unknown`
- Services total: 3960
- Distribution: SAT=3960, CABLE=0, TERRESTRIAL=0, RADIO=0
- Bouquets: 36
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
