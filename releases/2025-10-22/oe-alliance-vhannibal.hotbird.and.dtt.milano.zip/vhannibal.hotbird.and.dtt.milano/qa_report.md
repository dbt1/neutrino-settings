# QA Report – unknown

- Source ID: `unknown`
- Services total: 1955
- Distribution: SAT=1548, CABLE=0, TERRESTRIAL=407, RADIO=275
- Bouquets: 43
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
