# QA Report – unknown

- Source ID: `unknown`
- Services total: 2728
- Distribution: SAT=2728, CABLE=0, TERRESTRIAL=0, RADIO=0
- Bouquets: 34
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
