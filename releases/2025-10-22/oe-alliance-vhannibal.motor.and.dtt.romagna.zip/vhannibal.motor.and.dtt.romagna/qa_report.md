# QA Report – unknown

- Source ID: `unknown`
- Services total: 13007
- Distribution: SAT=12626, CABLE=0, TERRESTRIAL=381, RADIO=2005
- Bouquets: 48
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
