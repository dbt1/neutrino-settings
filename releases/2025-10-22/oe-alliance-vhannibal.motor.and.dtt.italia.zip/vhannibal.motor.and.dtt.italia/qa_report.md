# QA Report – unknown

- Source ID: `unknown`
- Services total: 12901
- Distribution: SAT=12627, CABLE=0, TERRESTRIAL=274, RADIO=2002
- Bouquets: 50
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
