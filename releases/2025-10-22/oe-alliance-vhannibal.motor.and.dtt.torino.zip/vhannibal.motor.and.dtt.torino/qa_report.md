# QA Report – unknown

- Source ID: `unknown`
- Services total: 14496
- Distribution: SAT=14097, CABLE=0, TERRESTRIAL=399, RADIO=2225
- Bouquets: 54
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
