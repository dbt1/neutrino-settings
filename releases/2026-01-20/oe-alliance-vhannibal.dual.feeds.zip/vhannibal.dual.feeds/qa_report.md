# QA Report – unknown

- Source ID: `unknown`
- Services total: 2590
- Distribution: SAT=2590, CABLE=0, TERRESTRIAL=0, RADIO=372
- Bouquets: 43
- Last seen: unknown
- Stale: unknown
- Thresholds: SAT≥50, CABLE≥20, TERRESTRIAL≥20

## Duplicates Removed
- None

## Warnings
- None
